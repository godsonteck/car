/* $OpenBSD: comp.h,v 1.13 2023/07/28 09:42:44 tb Exp $ */

/*
 * Public domain.
 *
 * This header is intentionally left empty. Some software uses it unnecessarily.
 */
